param([ValidateSet('All','Manufacturer','Speed','Type')][string]$Field='All')
# Read-only hardware discovery. No temporary files or writes.
$makers = 'Not reported'; $speeds = 'Unknown'; $types = 'Not reported'
try {
    $modules = @(Get-CimInstance -ClassName Win32_PhysicalMemory -ErrorAction Stop)
    if ($modules.Count -gt 0) {
        $m = @($modules | ForEach-Object { if ($_.Manufacturer -and $_.Manufacturer.Trim()) { $_.Manufacturer.Trim() } } | Select-Object -Unique)
        if ($m.Count -gt 0) { $makers = $m -join ', ' }
        $s = @($modules | ForEach-Object { if ($_.ConfiguredClockSpeed -gt 0) { [string]$_.ConfiguredClockSpeed } elseif ($_.Speed -gt 0) { [string]$_.Speed } } | Select-Object -Unique)
        if ($s.Count -gt 0) { $speeds = $s -join ', ' }
        $t = @($modules | ForEach-Object {
            $code = [int]$_.SMBIOSMemoryType
            if ($code -eq 0 -or $code -eq 2) { $code = [int]$_.MemoryType }
            switch ($code) { 24 {'DDR3'} 26 {'DDR4'} 30 {'LPDDR4'} 34 {'DDR5'} 35 {'LPDDR5'} 36 {'LPDDR5X'} default {'Not reported'} }
        } | Select-Object -Unique)
        if ($t.Count -gt 0) { $types = $t -join ', ' }
    }
} catch { } # Return safe values, never emit PowerShell exception text to Rainmeter.
switch ($Field) {
    'Manufacturer' { $makers }
    'Speed' { $speeds }
    'Type' { $types }
    default { "$makers|$speeds|$types" }
}
