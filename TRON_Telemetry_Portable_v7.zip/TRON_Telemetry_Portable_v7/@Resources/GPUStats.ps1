# Windows-native GPU telemetry, seven pipe-separated fields.
# load % | 3D engine % | dedicated MiB used | dedicated MiB capacity | adapter | shared MiB used | copy engine %
$ErrorActionPreference='SilentlyContinue'
$load='0'; $three='0'; $used='N/A'; $capacity='N/A'; $name='GPU not detected'; $shared='N/A'; $copy='0'
try {
  $cards=@(Get-CimInstance Win32_VideoController | Where-Object { $_.Name -and $_.Name -notmatch 'Microsoft Basic|Remote Display' })
  $card=$cards | Where-Object { $_.Name -match 'Radeon RX|GeForce|NVIDIA|Intel Arc' } | Select-Object -First 1
  if (-not $card) { $card=$cards | Select-Object -First 1 }
  if ($card) { $name=([string]$card.Name).Replace('|','/') }
} catch {}
try {
  $samples=@((Get-Counter '\GPU Engine(*)\Utilization Percentage' -ErrorAction Stop).CounterSamples)
  $groups=@($samples | Where-Object { $_.InstanceName -match 'engtype_' -and $_.CookedValue -ge 0 } | Group-Object { if ($_.InstanceName -match '(luid_0x[0-9a-f]+_0x[0-9a-f]+)') { $matches[1] } else { 'unknown' } })
  $best=0.0;$max3d=0.0;$maxcopy=0.0
  foreach($g in $groups) {
    $eng=@($g.Group | Group-Object { if ($_.InstanceName -match 'engtype_([^_]+)') {$matches[1]} else {'Other'} })
    foreach($e in $eng) {
      $sum=[double](($e.Group | Measure-Object -Property CookedValue -Sum).Sum)
      if($sum -gt $best){$best=$sum}
      if($e.Name -eq '3D' -and $sum -gt $max3d){$max3d=$sum}
      if($e.Name -eq 'Copy' -and $sum -gt $maxcopy){$maxcopy=$sum}
    }
  }
  $load=[string]([math]::Round([math]::Min(100,$best),1))
  $three=[string]([math]::Round([math]::Min(100,$max3d),1))
  $copy=[string]([math]::Round([math]::Min(100,$maxcopy),1))
} catch {}
try {
  $ded=@((Get-Counter '\GPU Adapter Memory(*)\Dedicated Usage' -ErrorAction Stop).CounterSamples | Where-Object { $_.CookedValue -ge 0 })
  if($ded.Count -gt 0){$used=[string]([math]::Round(($ded | Measure-Object CookedValue -Maximum).Maximum/1MB))}
} catch {}
try {
  $sha=@((Get-Counter '\GPU Adapter Memory(*)\Shared Usage' -ErrorAction Stop).CounterSamples | Where-Object { $_.CookedValue -ge 0 })
  if($sha.Count -gt 0){$shared=[string]([math]::Round(($sha | Measure-Object CookedValue -Maximum).Maximum/1MB))}
} catch {}
# Windows Win32_VideoController.AdapterRAM is often truncated at 4 GiB; only accept a credible value.
try {
  if($card -and $card.AdapterRAM -and [uint64]$card.AdapterRAM -lt 4294967295 -and [uint64]$card.AdapterRAM -gt 0){$capacity=[string]([math]::Round([double]$card.AdapterRAM/1MB))}
} catch {}
"$load|$three|$used|$capacity|$name|$shared|$copy"
